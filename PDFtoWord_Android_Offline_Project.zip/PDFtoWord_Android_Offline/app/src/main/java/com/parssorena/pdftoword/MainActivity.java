package com.parssorena.pdftoword;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.rendering.PDFRenderer;
import cz.adaptech.tesseract4android.TessBaseAPI;

public class MainActivity extends Activity {
  static final int PICK_PDF=10, SAVE_DOCX=11;
  WebView web; Uri pdfUri; File pendingDocx;
  @Override public void onCreate(Bundle b){ super.onCreate(b); PDFBoxResourceLoader.init(getApplicationContext());
    web=new WebView(this); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setAllowFileAccess(true); web.setWebChromeClient(new WebChromeClient()); web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new Bridge(),"Android"); setContentView(web); web.loadUrl("file:///android_asset/index.html"); }
  void status(String s){ runOnUiThread(()->web.evaluateJavascript("setStatus("+quote(s)+")",null)); }
  static String quote(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","")+"\"";}
  class Bridge {
    @JavascriptInterface public void choosePdf(){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/pdf");startActivityForResult(i,PICK_PDF);});}
    @JavascriptInterface public void convert(String mode){ if(pdfUri==null){status("ابتدا PDF انتخاب کن.");return;} status("در حال پردازش…"); new Thread(()->{try{
      File input=copyInput(pdfUri); String text=extract(input);
      if("ocr".equals(mode)||("auto".equals(mode)&&text.trim().length()<20)) text=ocr(input);
      if(text==null||text.trim().isEmpty()) throw new Exception("متنی پیدا نشد.");
      pendingDocx=new File(getCacheDir(),"PDFtoWord.docx"); writeDocx(text,pendingDocx);
      runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");i.putExtra(Intent.EXTRA_TITLE,"PDFtoWord.docx");startActivityForResult(i,SAVE_DOCX);});
    }catch(Exception e){status("خطا: "+(e.getMessage()==null?e.toString():e.getMessage()));}}).start();}
  }
  @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null){status("عملیات لغو شد.");return;}try{
    if(req==PICK_PDF){pdfUri=data.getData();getContentResolver().takePersistableUriPermission(pdfUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);web.evaluateJavascript("setFileName("+quote(pdfUri.getLastPathSegment()==null?"PDF انتخاب شد":pdfUri.getLastPathSegment())+")",null);status("فایل انتخاب شد. روش تبدیل را انتخاب کن.");}
    else if(req==SAVE_DOCX&&pendingDocx!=null){try(InputStream in=new FileInputStream(pendingDocx);OutputStream out=getContentResolver().openOutputStream(data.getData())){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}pendingDocx.delete();status("فایل DOCX ذخیره شد.");}
  }catch(Exception e){status("خطا: "+e.getMessage());}}
  File copyInput(Uri u)throws Exception{File f=new File(getCacheDir(),"input.pdf");try(InputStream in=getContentResolver().openInputStream(u);OutputStream out=new FileOutputStream(f)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}return f;}
  String extract(File f)throws Exception{try(PDDocument d=PDDocument.load(f)){PDFTextStripper s=new PDFTextStripper();s.setSortByPosition(true);return s.getText(d);}}
  String ocr(File f)throws Exception{
    File root=new File(getFilesDir(),"tesseract"), td=new File(root,"tessdata"); if(!td.exists()&&!td.mkdirs())throw new Exception("ساخت پوشه OCR ناموفق بود.");
    copyAssetIfPresent("tessdata/fas.traineddata",new File(td,"fas.traineddata")); copyAssetIfPresent("tessdata/eng.traineddata",new File(td,"eng.traineddata"));
    if(!new File(td,"fas.traineddata").exists())throw new Exception("مدل OCR فارسی موجود نیست. fas.traineddata را طبق README در assets/tessdata قرار بده.");
    try(PDDocument d=PDDocument.load(f)){PDFRenderer renderer=new PDFRenderer(d);TessBaseAPI api=new TessBaseAPI();if(!api.init(root.getAbsolutePath(),new File(td,"eng.traineddata").exists()?"fas+eng":"fas")){api.recycle();throw new Exception("راه‌اندازی OCR ناموفق بود.");}
      StringBuilder all=new StringBuilder();try{for(int p=0;p<d.getNumberOfPages();p++){status("OCR صفحه "+(p+1)+" از "+d.getNumberOfPages());Bitmap bm=renderer.renderImage(p,1.5f);api.setImage(bm);String t=api.getUTF8Text();if(t!=null)all.append(t).append("\n\n");bm.recycle();}}finally{api.recycle();}return all.toString();}
  }
  void copyAssetIfPresent(String asset,File out){try(InputStream in=getAssets().open(asset);OutputStream os=new FileOutputStream(out)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)os.write(b,0,n);}catch(Exception ignored){}}
  static String xml(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
  void add(ZipOutputStream z,String name,String data)throws Exception{z.putNextEntry(new ZipEntry(name));z.write(data.getBytes("UTF-8"));z.closeEntry();}
  void writeDocx(String text,File out)throws Exception{StringBuilder ps=new StringBuilder();for(String line:text.replace("\r","").split("\n",-1)){ps.append("<w:p><w:pPr><w:bidi/><w:jc w:val=\"right\"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii=\"Arial\" w:hAnsi=\"Arial\" w:cs=\"Tahoma\"/><w:rtl/></w:rPr><w:t xml:space=\"preserve\">").append(xml(line)).append("</w:t></w:r></w:p>");}
    String doc="<?xml version=\"1.0\" encoding=\"UTF-8\"?><w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>"+ps+"<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\"/></w:sectPr></w:body></w:document>";
    try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(out))){add(z,"[Content_Types].xml","<?xml version=\"1.0\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>");add(z,"_rels/.rels","<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>");add(z,"word/document.xml",doc);}
  }
}
